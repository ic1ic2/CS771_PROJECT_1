# CS771 Mini-Project 1: Comprehensive Project Guide & Requirements

**Topic:** Next-Day $\text{PM}_{2.5}$ Forecasting and Heatmap Generation  
**Dataset Locations:** Bihar (468 stations, Jan–Nov 2024) & Kanpur (76 sensors, Jul–Aug 2026)  
**Main Task:** At **12:00 noon on day $d$** (issue time), forecast $\text{PM}_{2.5}$ concentration ($\mu\text{g/m}^3$) across **all 468 stations in Bihar** for **12:00 noon on day $d+1$** (24-hour lead time), beat reference baselines, and interpolate forecasts into a state-wide geographic heatmap.

---

## 1. Datasets Provided

| File | Description | Layout & Details |
| :--- | :--- | :--- |
| `bihar_pm25_hourly_jan_nov_2024.csv` | Primary dataset for Parts 1–5 | **Wide format:** 8,040 rows (hourly, 1 Jan 00:00 – 30 Nov 23:00 2024 local IST), 468 columns (sensor IDs). No missing values (pre-filled upstream). |
| `bihar_stations.csv` | Locations of Bihar stations | Columns: `sensor_id`, `latitude`, `longitude` (exact same column order as the hourly file). |
| `bihar_grid_005deg.csv` | Bihar interpolation grid | 3,396 regular grid points across Bihar spaced at $0.05^\circ$ ($\approx 5\text{ km}$). Used for Part 4 mapping. |
| `bihar_boundary.csv` | Bihar state polygon | Coordinates (`longitude`, `latitude`) outlining the state boundary for map plotting. |
| `kanpur_pm25_raw_jul_aug_2026.csv` | Raw dataset for **Part 0 only** | 5,952 rows on a 15-minute UTC grid (1 Jul – 31 Aug 2026). 229 columns: 3 columns per sensor (`<id>_latitude`, `<id>_longitude`, `<id>_pm25`). Contains noise, dropouts, stuck values, and outliers. |

---

## 2. Fundamental Rules & Constraints

> [!IMPORTANT]
> **Strict temporal splitting & zero future leakage:**
> - **Training period:** Target timestamps on or before **31 August 2024** (Jan–Aug).
> - **Validation period:** Target timestamps from **1 September to 30 November 2024** (Sep–Nov, 91 noon days). All model selection, hyperparameter tuning, and ablation decisions must be made strictly on validation.
> - **Hidden Test period:** 1–30 December 2024 (withheld by course instructors).
> - **Zero leakage:** For any forecast issued at day $d$, 12:00, you may only use data up to that exact timestamp. Scalers, imputation values, station means, and encoders must be fitted **only on training rows**. Never randomly shuffle rows into a train/test split.

> [!WARNING]
> **Model Restrictions:**
> - **No Neural Networks / Deep Learning** (e.g., no PyTorch/TensorFlow, MLP, CNN, LSTM, etc.).
> - **Allowed methods:** Any classical machine learning method covered up to Lecture 16 (Ridge, Lasso, ElasticNet, Huber/Robust regression, Trees, Random Forests, Gradient Boosted Trees, Bagging, PCA, $k$-means, etc.).
> - **No external data:** No satellite data, meteorological reanalysis (ERA5), weather forecasts, or external air-quality datasets.

* **Distance Formula:** When calculating spatial distances in kilometres, use:
  $$x = (\text{longitude} - 85.5) \times 100.3, \quad y = (\text{latitude} - 25.7) \times 110.6, \quad \text{dist} = \sqrt{(\Delta x)^2 + (\Delta y)^2}$$

---

## 3. Detailed Breakdown by Project Part

```mermaid
flowchart TD
    A["Part 0: Raw Sensor Cleaning (Kanpur)"] --> B["Part 1: Required Baselines (Bihar)"]
    B --> C["Part 2: Feature Engineering & Model Improvement"]
    C --> D["Part 3: Lead-Time Sensitivity Analysis"]
    C --> E["Part 4: IDW Heatmap Interpolation & Evaluation"]
    C --> F["Part 5: Hidden Test Packaging (forecast.py)"]
```

---

### Part 0: Cleaning a Raw Sensor Dataset (Kanpur)
*Part 0 is a self-contained data-engineering and diagnostics exercise on real, messy low-cost sensor data.*

1. **Understand the Format:**
   - Report the total number of sensors (76).
   - Determine how often each sensor reports (15-min vs. hourly intervals).
   - Check whether any sensor moves over time (inspect lat/lon variance).
   - Analyze how the sensor ID styles (10-digit integers vs. 8-character floats vs. 12-character hex) differ in reporting resolution and typical values.
2. **Hourly Reshaping:**
   - Reshape into a long table: `sensor_id`, `timestamp_utc`, `latitude`, `longitude`, `pm25`.
   - Average readings within each hour (labeled by the hour start).
   - Compare hourly averaging against simply picking the reading at minute `:00` and quantify differences.
3. **Anomaly Detection & Flagging:**
   Detect and flag problematic readings rather than deleting them silently:
   - **Error codes:** Hardware saturation or error codes (e.g., $999.0\,\mu\text{g/m}^3$).
   - **Implausible zeros:** Unrealistic ambient readings of exactly $0.0\,\mu\text{g/m}^3$.
   - **Stuck values:** Identical reading repeated for $\ge 24$ consecutive reported hours.
   - **Mostly unusable sensors:** Sensors with $> 50\%$ of their readings flagged (dropped sensors).
   - **Network outages:** Hours when $< 10\%$ of sensors report.
   - Identify anomalous sensors that barely correlate with the network median.
4. **Export Cleaned Table:**
   - Write `kanpur_hourly_clean.csv` containing a `flag` column (`ok`, `error_code`, `zero`, `stuck`, `dropped_sensor`). Gaps must be left missing (no imputation).
5. **Cross-Family Calibration Check:**
   - Pair each 10-digit sensor with its nearest 8-character sensor if within $3\text{ km}$.
   - Fit a calibration regression (e.g., linear/additive/multiplicative) on July data and evaluate on August data. Explain whether it reduces inter-sensor disagreement.
6. **Summary:**
   - Provide a Before/After comparison table (sensor counts, valid readings, missing rate).
   - Plot the clean network average diurnal cycle in local Indian Standard Time ($\text{IST} = \text{UTC} + 5:30$).

---

### Part 1: Required Baselines (Bihar)
*Establish standard benchmarks on the Bihar dataset to evaluate all future improvements.*

1. **Persistence Baseline:**
   - Predict tomorrow at 12:00 = today's reading at 12:00 ($\hat{y}_{s, t+24} = y_{s, t}$).
2. **Ridge Regression Baseline:**
   - Construct **29 features** per station at or before issue time $t$ (day $d$, 12:00):
     - The station's 24 hourly readings: $t, t-1\text{h}, \dots, t-23\text{h}$ (24 features).
     - Mean of its 10 nearest neighbouring stations at $t$ (1 feature).
     - Mean of those 10 stations over the past 24 hours ($t-23\text{h} \dots t$) (1 feature).
     - Network mean (all 468 stations) at $t$ (1 feature).
     - Day-of-year harmonics: $\sin(2\pi d / 365)$ and $\cos(2\pi d / 365)$, where $d = \text{days since Jan 1}$ (2 features).
3. **Model Fitting & Prediction:**
   - Fit `sklearn.linear_model.Ridge(alpha=1.0)` on **raw, unscaled features**, pooling all 468 stations and all training days with 24h history (Jan–Aug).
   - Clip negative predictions to 0.
4. **Evaluation:**
   - Compute and report validation **RMSE** and **MAE**, both overall and month-by-month (Sep, Oct, Nov).
5. **Required Question to Answer:**
   - *Compare Persistence and Ridge on RMSE and MAE. Does one win on both metrics? Why might a model trained on squared error lose on absolute error?*

---

### Part 2: Improve the Forecast & Feature Ablation
*Develop a better forecasting pipeline using advanced feature engineering and model selection.*

1. **Feature Engineering Ideas:**
   - Multi-day historical lags (same hour 2–7 days ago).
   - Temporal trends (differences between today and yesterday/last week, short-term EMAs).
   - Multi-scale spatial neighborhood statistics ($K=5, 25, 50, 100$, IDW, directional upwind/downwind sectors).
   - Regional network statistics (network percentiles, dispersion, regional accumulation rate).
2. **Model Exploration & Hyperparameter Tuning:**
   - Compare Ridge regression against other allowed algorithms (e.g., HuberRegressor, HistGradientBoosting, Random Forests).
   - Tune hyperparameters (regularization strength $\alpha$, tree depths, scaling) strictly on validation data.
3. **Leave-One-Group-Out Feature Ablation Study:**
   - Group all candidate features into **3 to 8 logical feature groups** (e.g., Station 24h trajectory, Multi-day history, Local spatial neighborhood, Regional plume advection, Network regime, Calendar/static).
   - Starting from the full model, drop one group at a time, retrain with identical hyperparameters, and record the change in validation RMSE ($\Delta \text{RMSE}$).
   - Discard groups that do not justify their inclusion.
4. **Final Reporting & Mandatory Questions:**
   - Report final model validation RMSE and MAE (overall and per month) side-by-side with both baselines.
   - *What did each feature group contribute? Which ideas failed to help, and why?*
   - *Did a more flexible model (like a Random Forest or Boosted Trees) beat Ridge on validation? If it performed better on training data but worse on validation, explain why.*
   - *What missing information (e.g., weather/meteorology, boundary layer height, wind vectors) would help the model most?*

---

### Part 3: Lead-Time Sensitivity Analysis
*Investigate how prediction accuracy varies as the issue time gets closer to the target.*

1. **Protocol:**
   - Keep the target fixed at **12:00 noon on day $d+1$**.
   - Test 5 lead times: **1h** (issue at 11:00), **3h** (09:00), **6h** (06:00), **12h** (00:00 midnight), and **24h** (12:00 noon previous day).
   - For each lead time, evaluate:
     1. Persistence baseline.
     2. Part 1 Ridge baseline (refitted for that specific lead).
     3. Your Part 2 improved model.
2. **Analysis & Questions to Answer:**
   - Plot Validation RMSE vs. Lead Time for all three approaches.
   - Report 1-hour nowcast metrics separately from 24-hour day-ahead metrics.
   - *Why does the Persistence baseline exhibit non-monotonic behavior (a large error hump at 6h–12h leads while improving at 24h)? (Hint: analyze the diurnal cycle of $\text{PM}_{2.5}$.)*
   - *Do learned regression models show the same diurnal sensitivity?*
   - *Which lead time would you recommend for a public warning advisory, and what is the trade-off in forecasting accuracy?*

---

### Part 4: Forecast Maps vs. Observed Maps (Spatial Heatmaps)
*Translate station-level point predictions into continuous spatial heatmaps across Bihar.*

1. **Spatial Interpolation Protocol:**
   - Interpolate station readings onto the 3,396 coordinates of `bihar_grid_005deg.csv` using **Inverse-Distance Weighting (IDW)** with power $p=2$:
     $$w_j(g) = \frac{d(g, s_j)^{-2}}{\sum_{k=1}^{468} d(g, s_k)^{-2}}, \quad \hat{z}(g) = \sum_{j=1}^{468} w_j(g)\, z(s_j)$$
   - Apply the exact same IDW operator to both actual station observations and model forecasts.
2. **Visual Map Comparison on Three Selected Days:**
   - Select 3 representative validation days:
     1. A **clean day** (low state-wide $\text{PM}_{2.5}$).
     2. A **polluted day** (severe air pollution episode).
     3. The day with your model's **worst station RMSE**.
   - For each day, plot 4 maps side-by-side:
     - Observed IDW Map
     - Your Model's Forecast IDW Map
     - Persistence Forecast IDW Map
     - Difference Map ($\text{Forecast} - \text{Observed}$)
   - Plot the state boundary outline, station dots, and a shared colorbar with units ($\mu\text{g/m}^3$).
3. **Map Metrics over All 91 Validation Days:**
   - **Map RMSE:** Root mean squared difference across all 3,396 grid cells.
   - **Pattern Correlation:** Pearson correlation across grid cells between the forecast map and the observed map.
   - Report average Map RMSE and Pattern Correlation vs. Station RMSE.
4. **Mandatory Questions to Answer:**
   - *Which RMSE is lower: Map RMSE or Station RMSE? Which one represents true forecast accuracy and should be quoted?*
   - *In what sense is the "observed map" not ground truth?*
   - *Can a forecast have high pattern correlation but poor RMSE? Give an example and discuss which metric matters more for public health advisories.*

---

### Part 5: Hidden December Test Set Submission
*Package and verify your final forecasting model for automated grading on withheld December 2024 data.*

1. **Model Refit:**
   - Retrain your chosen Part 2 model on **all available data up to 30 November 2024** (Jan–Nov combined).
2. **Submission Structure (`forecast.py`):**
   - Provide a clean `forecast.py` script containing the function:
     ```python
     def forecast(history: pd.DataFrame, issue_time: pd.Timestamp) -> pd.Series:
         """
         history: wide DataFrame (DatetimeIndex 'timestamp', 468 sensor_id columns)
                  contains hourly data up to and including issue_time (12:00 IST).
         Returns: pd.Series of 468 non-negative PM2.5 forecasts for issue_time + 24h,
                  indexed by sensor_id strings.
         """
     ```
   - Load pre-trained weights from serialized files (`model.pkl`) at module import time; **do not refit inside `forecast()`**.
3. **Verification via `check_submission.py`:**
   - Must run within the **10.0-second time limit per call**.
   - Must return non-negative, finite numbers for all 468 stations with matching string sensor IDs.
   - Verified locally on 30 issue times in November using:
     ```bash
     python starter/check_submission.py <path_to_submission_folder>
     ```

---

## 4. Deliverables Checklist & Grading Scheme

Your submission must be a single `.zip` file containing:

```
submission.zip
├── mp1_solution.ipynb        # Single notebook that runs top-to-bottom reproducing all parts
├── kanpur_hourly_clean.csv   # Cleaned Kanpur hourly table with 'flag' column (Part 0)
├── report.pdf / report.md    # Max 6-page report answering all questions with figures & AI declaration
├── forecast.py               # Grader-ready forecasting script (Part 5)
├── model.pkl                 # Pre-trained model artifact loaded by forecast.py
├── bihar_stations.csv        # Station coordinates (if required by forecast.py)
└── figures/                  # Publication-quality figure files generated by the notebook
```

### Grading Weightage (Total: 100 Marks)

| Component | Marks | Key Evaluation Criteria |
| :--- | :---: | :--- |
| **Part 0: Kanpur Cleaning** | **15** | All problem types identified with justified thresholds; hourly averaging implemented correctly; flagged clean table without synthetic gap-filling; honest calibration test and explanation. |
| **Part 1: Required Baselines** | **15** | Correct reproduction of Persistence and Ridge baselines; thoughtful and mathematically sound answer to the RMSE vs. MAE tradeoff question. |
| **Part 2: Improvement** | **20** | Rigorous train/val separation (no leakage); structured ablation table (3–8 feature groups); clear explanation of what helped and what failed; model comparison against non-linear models. |
| **Part 3: Lead Time** | **15** | Evaluation curves for all 5 leads (1h, 3h, 6h, 12h, 24h); clear physical explanation of the diurnal persistence hump; justified warning-service recommendation. |
| **Part 4: Heatmaps** | **15** | Correct IDW ($p=2$) implementation; clear 4-panel comparison plots on 3 required days; correct answers regarding map vs. station RMSE, pattern correlation, and limitations of interpolated truth. |
| **Part 5: Hidden Test** | **10** | **5 marks:** `forecast.py` executes without errors within 10s per call on withheld December data.<br>**5 marks:** Final model beats the Persistence baseline on December test RMSE. |
| **Report, Code & Viva** | **10** | Clean, reproducible code; well-labeled figures with units; honest error analysis; concise declaration of AI tools used; individual understanding during the 10-minute viva. |
